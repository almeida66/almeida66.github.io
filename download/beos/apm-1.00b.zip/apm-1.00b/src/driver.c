/* ++++++++++
	driver.c
	A skeletal device driver
+++++ */
#include <drivers/KernelExport.h>
#include <drivers/Drivers.h>
#include <support/Errors.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include "apmintl.h"
#include "apmdrv.h"

#define	DRIVER_NAME	"apm"
#define	DEVICE_NAME	"misc/apm"

#define	DPRINTF_INFO(x)

int32	api_version = B_CUR_DRIVER_API_VERSION;

/* ----------
	init_hardware - called once the first time the driver is loaded
----- */
_EXPORT status_t
init_hardware (void)
{
	DPRINTF_INFO ((DRIVER_NAME ": init_hardware()\n"));
	if (!apm_enabled)
		apm_init ();
	return B_OK;
}


/* ----------
	init_driver - optional function - called every time the driver
	is loaded.
----- */
_EXPORT status_t
init_driver (void)
{
	DPRINTF_INFO ((DRIVER_NAME ": init_driver()\n"));
	if (!apm_enabled)
	{
		apm_init ();
	}
	if (apm_enabled)
	{
		DPRINTF_INFO (("APM: registering task with kernel_daemon\n"));
		register_kernel_daemon (apm_daemon, NULL, 10);
	}
	return B_OK;
}


/* ----------
	uninit_driver - optional function - called every time the driver
	is unloaded
----- */
_EXPORT void
uninit_driver (void)
{
	DPRINTF_INFO ((DRIVER_NAME ": uninit_driver()\n"));
	if (apm_enabled)
		unregister_kernel_daemon (apm_daemon, NULL);
}

	
/* ----------
	my_device_open - handle open() calls
----- */

static status_t
my_device_open (const char *name, uint32 flags, void** cookie)
{
	DPRINTF_INFO ((DRIVER_NAME ": open(\"%s\")\n", name));
	return B_OK;
}


/* ----------
	my_device_read - handle read() calls
----- */

static status_t
my_device_read (void* cookie, off_t position, void *buf, size_t* num_bytes)
{
	DPRINTF_INFO ((DRIVER_NAME ": read():\n"));
	*num_bytes = 0;
	return B_IO_ERROR;
}


/* ----------
	my_device_write - handle write() calls
----- */

static status_t
my_device_write (void* cookie, off_t position, const void* buffer, size_t* num_bytes)
{
	DPRINTF_INFO ((DRIVER_NAME ": write():\n"));
	*num_bytes = 0;				/* tell caller nothing was written */
	return B_IO_ERROR;
}


/* ----------
	my_device_control - handle ioctl calls
----- */

static status_t
my_device_control (void* cookie, uint32 op, void* arg, size_t len)
{
	status_t	result = B_OK;
	uint16		*regs;

	DPRINTF_INFO ((DRIVER_NAME ": ioctl(%lu)\n", op));
	if (!apm_enabled)
		return B_ERROR;
	switch (op)
	{
	case APM_CONTROL:
		result = apm_control (*(int *)arg);
		break;
	case APM_DUMP_POWER_STATUS:
#if B_BEOS_VERSION == 0x0400
		dump_power_status ();
#endif
		break;
	case APM_BIOS_CALL:
		regs = (uint16 *)arg;
		result = apm_bios_call (&regs [0], &regs [1], &regs [2], 
			&regs [3], &regs [4], &regs [5]);
		break;
	case APM_SET_SAFETY:
		safety = *(bool *)arg;
		break;
	}
	return result;
}


/* ----------
	my_device_close - handle close() calls
----- */

static status_t
my_device_close (void* cookie)
{
	DPRINTF_INFO ((DRIVER_NAME ": close()\n"));
	return B_OK;
}


/* -----
	my_device_free - called after the last device is closed, and after
	all i/o is complete.
----- */
static status_t
my_device_free (void* cookie)
{
	DPRINTF_INFO ((DRIVER_NAME ": free()\n"));
	return B_OK;
}


/* -----
	null-terminated array of device names supported by this driver
----- */

static const char *my_device_name[] = {
	DEVICE_NAME,
	NULL
};

/* -----
	function pointers for the device hooks entry points
----- */

static device_hooks my_device_hooks = {
	my_device_open, 			/* -> open entry point */
	my_device_close, 			/* -> close entry point */
	my_device_free,			/* -> free cookie */
	my_device_control, 		/* -> control entry point */
	my_device_read,			/* -> read entry point */
	my_device_write			/* -> write entry point */
};

/* ----------
	publish_devices - return a null-terminated array of devices
	supported by this driver.
----- */

_EXPORT const char**
publish_devices()
{
	DPRINTF_INFO ((DRIVER_NAME ": publish_devices()\n"));
	return my_device_name;
}

/* ----------
	find_device - return ptr to device hooks structure for a
	given device name
----- */

_EXPORT device_hooks*
find_device(const char* name)
{
	int	i;

	DPRINTF_INFO ((DRIVER_NAME ": find_device(\"%s\")\n", name));
	for (i = 0; my_device_name [i] != NULL; i++)
		if (strcmp (name, my_device_name [i]) == 0)
			return &my_device_hooks;
	return NULL;
}

