#ifndef	_APMINTL_H_
#define	_APMINTL_H_

#include <support/SupportDefs.h>
#include "apm.h"

/* kernel exported variables and functions */

extern uint8 apm_enabled;

/* APM initialization etc. */

status_t apm_control(int apm_state);
void apm_init(void);
void dump_power_status(void);
void apm_daemon (void *arg, int freq);	/* arguments are not used */
char *apm_strerror (status_t apm_errno);

/* APM BIOS calls */

/* XXX: Return value in *ax is garbage; should be reimplemented */
uint8 apm_bios_call (uint16 *ax, uint16 *bx, uint16 *cx, uint16 *dx, 
	uint16 *si, uint16 *di);

status_t apm_interface_disconnect (void);
status_t apm_cpu_idle(void);
status_t apm_cpu_busy(void);
status_t apm_set_power_state(uint16 power_device_id, uint16 power_state);
status_t apm_enable_power_management(uint16 power_device_id);
status_t apm_disable_power_management(uint16 power_device_id);
status_t apm_get_power_status(uint16 power_device_id, 
	 uint8 *ac_line_status,
	 uint8 *battery_status,
	 uint8 *battery_flag,
	 uint8 *battery_percent,
	 uint16 *battery_time, uint16 *batteries);
status_t apm_get_pm_event(uint16 *pm_event_code, uint16 *pm_event_info);
status_t apm_driver_version(uint16 driver_version);
status_t apm_engage_power_management(uint16 power_device_id);
status_t apm_disengage_power_management(uint16 power_device_id);

int get_boot_item_size (char *name);
void *get_boot_item (char *name);

/* driver specific variables and functions */

extern bool safety;

#endif
