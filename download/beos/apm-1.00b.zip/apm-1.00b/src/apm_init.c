#include <drivers/KernelExport.h>
#include <drivers/Drivers.h>
#include <support/Errors.h>
#if B_BEOS_VERSION >= 0x0450
#include <drivers/driver_settings.h>
#endif
#include "apmintl.h"

#define	APM_WORKAROUND

extern struct
{
#if B_BEOS_VERSION == 0x0400
	uint16	driver_version;	/* 0 */
	uint16	cseg32_base;	/* 2 */
	uint32	cseg32_offset;	/* 4 */
	uint16	cseg16_base;	/* 8 */
	uint16	dseg_base;		/* a */
	uint16	unknown;		/* c */
	uint16	cseg16_size;	/* e */
	uint16	cseg32_size;	/* 10 */
	uint16	dseg_size;		/* 12 */
#else
	uint16	driver_version;	/* 0 */
	uint16	unknown1;
	uint16	cseg32_base;	/* 4 */
	uint16	unknown2;
	uint32	cseg32_offset;	/* 8 */
	uint16	cseg16_base;	/* c */
	uint16	dseg_base;		/* e */
	uint16	cseg32_size;	/* 10 */
#define	cseg16_size cseg32_size
	uint16	dseg_size;		/* 12 */
#endif
} *apm_info;

extern struct fword_ptr
{
	uint32	offset;
	uint16	selector;
} apm_bios;

/* segment selectors (including lowest 3 bits) */

#define	CS32	0x48
#define	CS16	0x50
#define	DS		0x58

struct seg_desc_t
{
	uint16	limit_l;	/* limit[15:0] */
	uint16	base_l;		/* base[15:0] */
	uint8	base_m;		/* base[23:16] */
	uint8	rights;		/* P, DPL, S, TYPE, A bits */
	uint8	limit_h;	/* G, D bits and limit[19:16] */
	uint8	base_h;		/* base[31:24] */
};

extern struct seg_desc_t *gdt;

void apm_init(void)
{
#if B_BEOS_VERSION >= 0x0450
	bool	flag;
	system_info	sysinfo;
	register void * handle;
#endif
	area_id	dseg_area;
	void	*dseg_area_addr;
	struct seg_desc_t	*sd;
	uint32	base, size, aligned_base, aligned_size;

#if B_BEOS_VERSION >= 0x0450
	handle = load_driver_settings ("kernel");
	flag = 0;
	if (get_driver_boolean_parameter (handle, "bios_calls", true, true))
		flag = get_driver_boolean_parameter (handle, "_apm", false, true);
	unload_driver_settings (handle);
	if (!flag) return;
	_get_system_info (&sysinfo, sizeof sysinfo);
	if (sysinfo.cpu_count > 1)
	{
		dprintf ("APM disabled on MP systems\n");
		return;
	}
#endif
	dprintf ("*** apm_init\n");

	/* obtain APM BIOS info */

	apm_info = get_boot_item ("apm_info");
	if (apm_info == NULL)
	{
		dprintf ("APM: no info passed by the bootloader!\n");
		return;
	}
	if (apm_info->driver_version == 0)
	{
		dprintf ("APM is not present\n");
		return;
	}
	apm_bios.selector = CS32;
	apm_bios.offset = apm_info->cseg32_offset;
	dprintf ("apm_info @ 0x%p (%x:%lx)\n", apm_info, CS32, apm_bios.offset);

	dprintf ("APM: CS32 base 0x%x, size 0x%x\n",
		apm_info->cseg32_base,
		apm_info->cseg32_size);
	dprintf ("APM: CS16 base 0x%x, size 0x%x\n",
		apm_info->cseg16_base,
		apm_info->cseg16_size);
	dprintf ("APM: DS   base 0x%x, size 0x%x\n",
		apm_info->dseg_base,
		apm_info->dseg_size);

	/* build segment descriptors */

#ifdef APM_WORKAROUND
	/* Some APM BIOS implementaions do not return correct size of 
	code/data segments in ESI/DI registers.
	They may contain too small garbage values,
	which could cause segmentation fault */
	if (apm_info->cseg32_size < 0x100 || apm_info->cseg32_size < apm_info->cseg32_offset)
		apm_info->cseg32_size = 0xffff;
	if (apm_info->cseg16_size < 0x100 || apm_info->cseg16_size < apm_info->cseg32_offset)
		apm_info->cseg16_size = apm_info->cseg32_size;
	if (apm_info->dseg_size < 0x100)
		apm_info->dseg_size = 0xffff;
#endif

	sd = &gdt [CS32 / 8];
	base = apm_info->cseg32_base << 4;
	sd->limit_l = apm_info->cseg32_size - 1;
	sd->limit_h = 0x40;	/* byte granular, 32-bit */
	sd->base_l = base;
	sd->base_m = base >> 16;
	sd->base_h = 0;
	sd->rights = 0x9a;	/* present, DPL=0, ordinary descriptor,
				non-conforming code segment, readable */
	dprintf ("APM_CS32 done\n");

	sd = &gdt [CS16 / 8];
	base = apm_info->cseg16_base << 4;
	sd->limit_l = apm_info->cseg16_size - 1;
	sd->limit_h = 0x00;	/* byte granular, 16-bit */
	sd->base_l = base;
	sd->base_m = base >> 16;
	sd->base_h = 0;
	sd->rights = 0x9a;	/* present, DPL=0, ordinary descriptor,
				non-conforming code segment, readable */
	dprintf ("APM_CS16 done\n");

	sd = &gdt [DS / 8];
	base = apm_info->dseg_base;
	base <<= 4;
	size = apm_info->dseg_size;
#ifdef APM_WORKAROUND
	/* data segment must be accessible by linear address */

	if (size > 0)
	{
		aligned_base = base & ~(B_PAGE_SIZE - 1);
		aligned_size = ((base - aligned_base) + size + B_PAGE_SIZE - 1) 
			& ~(B_PAGE_SIZE - 1);
		dprintf ("APM: mapping dseg area: %lx(%lx) as %lx(%lx) ", base, size,
			aligned_base, aligned_size);
		dseg_area = map_physical_memory (
			"apm_dseg", (void *)aligned_base, aligned_size, 
			B_ANY_KERNEL_ADDRESS, B_WRITE_AREA | B_READ_AREA, 
			(void **)&dseg_area_addr);
		if (dseg_area < 0)
			dprintf ("failed: error %d\n", (int) dseg_area);
		else
		{
			dprintf ("mapped at %p\n", dseg_area_addr);
			base = (uint32) dseg_area_addr + (base - aligned_base);
		}
	}
#endif
	sd->limit_l = apm_info->dseg_size - 1;
	sd->limit_h = 0x40;	/* byte granular, 32-bit */
	sd->base_l = base;
	sd->base_m = base >> 16;
	sd->base_h = base >> 24;
	sd->rights = 0x92;	/* present, DPL=0, ordinary descriptor,
				data segment, writable */
	dprintf ("APM_DS done\n");

	/* notify driver version */

	dprintf ("APM: setting driver version to %d.%d\n", 
		apm_info->driver_version >> 8,
		apm_info->driver_version & 255);
	if (apm_driver_version (apm_info->driver_version) != B_OK)
	{
		dprintf ("APM: can't set the driver version...trying 1.1\n");
		apm_info->driver_version = APM_VERSION_1_1;
		if (apm_driver_version (APM_VERSION_1_1) != B_OK)
			dprintf ("APM: can't set the driver version to 1.1!\n");
	}

	/* engage/enable power mgmt */
	/* ThinkPad i 1450 requires enabling first */
	/* Asus P2B fails both calls :-( */
	/* Some recent notebooks may need both or either of these calls omitted */

	dprintf ("APM: enabling power management\n");
	if (apm_enable_power_management (APM_DEVICE_ALL) != B_OK)
		dprintf ("APM: can't enable power management!\n");

	dprintf ("APM: engaging power management\n");
	if (apm_engage_power_management (APM_DEVICE_ALL) != B_OK)
		dprintf ("APM: can't engage power management!\n");

	apm_enabled = 1;
}

