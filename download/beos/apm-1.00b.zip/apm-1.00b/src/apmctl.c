#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <ctype.h>
#include <drivers/Drivers.h>
#include "apm.h"
#include "apmdrv.h"

void usage (void)
{
	fputs ("usage:\n"
		"\tapmctl status\n"
		"\tapmctl standby (danger)\n"
		"\tapmctl suspend on|off\n"
		"\tapmctl suspend (danger)\n"
		"\tapmctl poweroff (danger)\n"
		"\tapmctl bios AX [BX [CX [DX [SI [DI]]]]] (danger)\n"
		, stderr);
}

void PrintPowerState (uint8 ac_line_status, uint8 battery_status,
	uint8 battery_flag, uint8 battery_percent,
	uint16 battery_time, uint16 batteries)
{
	printf ("AC line status: ");
	switch (ac_line_status)
	{
	case 0:		printf ("off-line\n");	break;
	case 1:		printf ("on-line\n");	break;
	case 2:		printf ("backup power\n");	break;
	default:	printf ("unknown\n");	break;
	}

	printf ("Battery status: ");
	switch (battery_status)
	{
	case 0:		printf ("high\n");	break;
	case 1:		printf ("low\n");	break;
	case 2:		printf ("CRITICAL\n");	break;
	case 3:		printf ("charging\n");	break;
	default:	printf ("unknown\n");	break;
	}	

	printf ("Battery life  : ");
	if (battery_percent <= 100)
	{
		printf ("%u%% remaining", battery_percent);
		if (battery_time < 0xFFFF)
		{
			if (battery_time & 0x8000)
				printf (" (%u minutes)\n", battery_time & 0x7FFF);
			else
				printf (" (%u seconds)\n", battery_time);
		}
		else
			putchar ('\n');
	}
	else 
		printf ("unknown\n");
}

int main (int argc, char **argv)
{
	int	fd, result;
	uint16	regs [6] = { 0, 0, 0, 0, 0, 0 };
	const char *regnames [] = { "AX", "BX", "CX", "DX", "SI", "DI" };

	if (argc < 2)
	{
		usage ();
		exit (1);
	}

	fd = open (APM_DEVICE_PATH, O_RDONLY);
	if (fd < 0)
	{
		fputs ("failed to open APM driver\n", stderr);
		exit (1);
	}

	if (strcmp (argv [1], "standby") == 0)
	{
		sleep (1);	/* wait for Enter key to be released */
		regs [0] = APM_FUNC_OFFSET + APM_FUNC_SET_POWER_STATE;
		regs [1] = APM_DEVICE_ALL;
		regs [2] = APM_STATE_STANDBY;
		result = ioctl (fd, APM_BIOS_CALL, regs);
	}
	else if (strcmp (argv [1], "suspend") == 0)
	{
		if (argc == 2)
		{
			puts ("Sync'ing...");
			sync ();
			sleep (5);
			regs [0] = APM_FUNC_OFFSET + APM_FUNC_SET_POWER_STATE;
			regs [1] = APM_DEVICE_ALL;
			regs [2] = APM_STATE_SUSPEND;
			result = ioctl (fd, APM_BIOS_CALL, regs);
		}
		else if (strcmp (argv [2], "on") == 0)
		{
			bool	safety = false;
			result = ioctl (fd, APM_SET_SAFETY, &safety);
		}
		else if (strcmp (argv [2], "off") == 0)
		{
			bool	safety = true;
			result = ioctl (fd, APM_SET_SAFETY, &safety);
		}
		else
		{
			usage ();
			exit (1);
		}
	}
	else if (strcmp (argv [1], "poweroff") == 0)
	{
		char	buf [256];

		printf ("System power off!!! Are you really sure? (y/n) ");
		gets (buf);
		if (tolower (buf [0]) == 'y')
		{
			puts ("Sync'ing...");
			sync ();
			sleep (5);
			regs [0] = APM_FUNC_OFFSET + APM_FUNC_SET_POWER_STATE;
			regs [1] = APM_DEVICE_ALL;
			regs [2] = APM_STATE_OFF;
			result = ioctl (fd, APM_BIOS_CALL, regs);
		}
	}
	else if (strcmp (argv [1], "status") == 0)
	{
		uint8	ac_line_status, battery_status, 
			battery_flag, battery_percent;
		uint16	battery_time, batteries;

		regs [0] = APM_FUNC_OFFSET + APM_FUNC_GET_POWER_STATUS;
		regs [1] = APM_DEVICE_ALL;
		result = ioctl (fd, APM_BIOS_CALL, regs);
		ac_line_status  = regs [1] >> 8;
		battery_status  = regs [1] & 255;
		battery_flag    = regs [2] >> 8;
		battery_percent = regs [2] & 255;
		battery_time    = regs [3];
		batteries       = regs [4];
		PrintPowerState (ac_line_status, battery_status,
			battery_flag, battery_percent,
			battery_time, batteries);
	}
	else if (strcmp (argv [1], "bios") == 0)
	{
		int	i;

		for (i = 2; i < argc; i++)
			sscanf (argv [i], "%hx", &regs [i - 2]);
		regs [0] = (regs [0] & 0xFF) | APM_FUNC_OFFSET;
		result = ioctl (fd, APM_BIOS_CALL, regs);
		printf ("Result: %04X\n", result);
		for (i = 1; i < 6; i++)
			printf ("%s: %04X\n", regnames [i], regs [i]);
	}
	else
	{
		usage ();
		exit (1);
	}
	close (fd);
	exit (0);
}
