#ifndef	_APMDRV_H_
#define	_APMDRV_H_

#include <drivers/Drivers.h>
#include "apm.h"

#define	APM_DEVICE_PATH	"/dev/misc/apm"

enum
{
	APM_CONTROL = B_DEVICE_OP_CODES_END + 1,
	APM_DUMP_POWER_STATUS,
	APM_BIOS_CALL,
	APM_SET_SAFETY
};

#endif
