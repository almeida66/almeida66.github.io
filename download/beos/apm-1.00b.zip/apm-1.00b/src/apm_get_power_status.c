#include <drivers/KernelExport.h>
#include <drivers/Drivers.h>
#include <support/Errors.h>
#include "apmintl.h"

status_t apm_get_power_status
	(uint16 power_device_id, 
	 uint8 *ac_line_status,
	 uint8 *battery_status,
	 uint8 *battery_flag,
	 uint8 *battery_percent,
	 uint16 *battery_time, uint16 *batteries)
{
	uint16	ax, bx, cx, dx, si, di;

	ax = APM_FUNC_OFFSET + APM_FUNC_GET_POWER_STATUS;
	bx = power_device_id;
	if (apm_bios_call (&ax, &bx, &cx, &dx, &si, &di) != 0)
		return B_ERROR;
	*ac_line_status  = bx >> 8;
	*battery_status  = bx & 255;
	*battery_flag    = cx >> 8;
	*battery_percent = cx & 255;
	*battery_time    = dx;
	*batteries       = si;
	return B_OK;
}

