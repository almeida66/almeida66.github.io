#include <drivers/KernelExport.h>
#include <support/Errors.h>
#include "apmintl.h"

#define	DPRINTF_INFO(x)

bool safety = true;

void apm_daemon (void *arg, int freq)
{
	uint16	pm_event_code, pm_event_info;
	uint8	ac_line_status, battery_status, battery_flag, battery_percent;
	uint16	battery_time, batteries;

	while (apm_get_pm_event (&pm_event_code, &pm_event_info) == B_OK)
	{
		DPRINTF_INFO (("APM event: code = 0x%x, info = 0x%x\n", 
			pm_event_code, pm_event_info));
		switch (pm_event_code)
		{
		case APM_EVENT_SYSTEM_STANDBY:
		case APM_EVENT_USER_STANDBY:
			apm_set_power_state (APM_DEVICE_ALL, APM_STATE_STANDBY);
			break;

		case APM_EVENT_SYSTEM_SUSPEND:
		case APM_EVENT_CRITICAL_SUSPEND:
		case APM_EVENT_USER_SUSPEND:
			if (safety)
			{
				apm_set_power_state (APM_DEVICE_ALL, APM_STATE_REJECTED);
				apm_set_power_state (APM_DEVICE_ALL, APM_STATE_STANDBY);
			}
			else
				apm_set_power_state (APM_DEVICE_ALL, APM_STATE_SUSPEND);
			break;

		case APM_EVENT_NORMAL_RESUME:
		case APM_EVENT_CRITICAL_RESUME:
			/* pm_event_info bit0 is significant */
			/* update system clock */
			break;

		case APM_EVENT_UPDATE_TIME:
		case APM_EVENT_STANDBY_RESUME:
			/* update system clock */
			break;

		case APM_EVENT_BATTERY_LOW:
			break;

		case APM_EVENT_POWER_STATUS_CHANGE:
			apm_get_power_status (APM_DEVICE_ALL, 
				&ac_line_status, &battery_status, 
				&battery_flag, &battery_percent, 
				&battery_time, &batteries);
			DPRINTF_INFO (("APM power status: "
				"AC line %d, batt stat %d, "
				"batt flag %d, batt perc %d, "
				"batt time %d, batts %d\n", 
				ac_line_status, battery_status,
				battery_flag, battery_percent,
				battery_time, batteries));
			break;

		case APM_EVENT_CAPABILITIES_CHANGE:
			/* Get Capabilities call */
			apm_get_power_status (APM_DEVICE_ALL, 
				&ac_line_status, &battery_status, 
				&battery_flag, &battery_percent, 
				&battery_time, &batteries);
			break;
		}
	}
}

