#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include "apmdrv.h"

int	main	(void)
{
	int	fd;

	fd = open (APM_DEVICE_PATH, O_RDONLY);
	if (fd < 0)
	{
		perror ("open()");
		exit (1);
	}
#if 0
	/* pause()/sigsuspend() causes stack overflow!! */
	pause ();
#else
	for (;;)
		sleep (UINT_MAX);
#endif
	close (fd);
	exit (0);
}

