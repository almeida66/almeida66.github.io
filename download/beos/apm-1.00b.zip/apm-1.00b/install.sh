#! /bin/sh
OBJ_DIR=obj.x86
NAME=apm
DRIVER_PATH=misc
USER_BIN_PATH=/boot/home/config/add-ons/kernel/drivers/bin
USER_DEV_PATH=/boot/home/config/add-ons/kernel/drivers/dev
USER_BOOT_SCRIPT=/boot/home/config/boot/UserBootscript
CONFIG_DIR=/boot/home/config/settings/kernel/drivers
CONFIG_FILE=kernel

RETURN=`alert "Installing APM Driver?" "Continue" "Cancel"`

if [[ $RETURN = Continue ]]
then
       cd /boot/home/config/add-ons/kernel

             mkdir drivers
             cd drivers

             mkdir bin
             cd bin


PREFIX=/tmp/apm$$
TMP_FILE=$PREFIX.tmp

finish ()
{
rm -f $PREFIX*
exit $1
}

make_config_file ()
{
if [ ! -e $CONFIG_DIR/$CONFIG_FILE ]
then
	if [ -e $CONFIG_DIR/sample/$CONFIG_FILE ]
	then
		cp $CONFIG_DIR/sample/$CONFIG_FILE $CONFIG_DIR/$CONFIG_FILE
	elif [ -e $CONFIG_DIR/sample/$CONFIG_FILE.sample ]
	then
		cp $CONFIG_DIR/sample/$CONFIG_FILE.sample $CONFIG_DIR/$CONFIG_FILE
	else
		touch $CONFIG_DIR/$CONFIG_FILE
	fi
fi
}

install_driver ()
{
if [ -f $OBJ_DIR/$NAME ]
then
	# make driverinstall
	copyattr --data $OBJ_DIR/$NAME $USER_BIN_PATH/$NAME
	mkdir -p $USER_DEV_PATH/$DRIVER_PATH
	ln -sf $USER_BIN_PATH/$NAME $USER_DEV_PATH/$DRIVER_PATH/$NAME

else
	alert --stop "Files are missing." Quit > /dev/null
	finish 1
fi
}

#
# main
#

cd "`dirname \"$0\"`"		# for being called from Tracker

install_driver
copyattr --data $OBJ_DIR/apmd $OBJ_DIR/apmctl $HOME/config/bin

# modify kernel settings file under R4.5/R5
if [ `uname -r` != 4.0 ]
then
	make_config_file
	if grep -q 'added by APM driver' $CONFIG_DIR/$CONFIG_FILE
	then
		true
	else
		sed -f disable.sed $CONFIG_DIR/$CONFIG_FILE > $TMP_FILE
		cat << END >> $TMP_FILE

bios_calls enabled	# added by APM driver installer
apm false		# added by APM driver installer
_apm true		# added by APM driver installer
enable_shutdown true	# added by APM driver installer

END
		mv -f $TMP_FILE $CONFIG_DIR/$CONFIG_FILE
	fi
fi

grep -q 'apmd ' $USER_BOOT_SCRIPT || cat << END >> $USER_BOOT_SCRIPT

ls /dev/misc > /dev/null	# added by APM driver installer

END

alert --info "APM Driver has been installed and APM has been enabled.
Reboot the system."

finish 0;

fi
