#! /bin/sh
OBJ_DIR=obj.x86
NAME=apm
DRIVER_PATH=misc
USER_BIN_PATH=/boot/home/config/add-ons/kernel/drivers/bin
USER_DEV_PATH_MISC=/boot/home/config/add-ons/kernel/drivers/dev/misc
USER_DEV_PATH=/boot/home/config/add-ons/kernel/drivers/dev/
USER_DRIVERS_PATH=/boot/home/config/add-ons/kernel/drivers/
USER_BOOT_SCRIPT=/boot/home/config/boot/UserBootscript
CONFIG_DIR=/boot/home/config/settings/kernel/drivers
CONFIG_FILE=kernel

PREFIX=/tmp/apm$$
TMP_FILE=$PREFIX.tmp

cd "`dirname \"$0\"`"		# for being called from Tracker

RETURN=`alert "Uninstalling APM Driver?" "Continue" "Cancel"`

if [[ $RETURN = Continue ]]
then
       
            rm -f $USER_BIN_PATH/$NAME 
            rm -f $USER_DEV_PATH/$DRIVER_PATH/$NAME
            rmdir $USER_BIN_PATH
            rmdir $USER_DEV_PATH_MISC
            rmdir $USER_DEV_PATH
            rmdir $USER_DRIVERS_PATH

rm -f $HOME/config/bin/apmd $HOME/config/bin/apmctl

# modify kernel settings file under R4.5/R5
if [ `uname -r` != 4.0 ]
then
	grep -v "added by APM driver" $CONFIG_DIR/$CONFIG_FILE > $TMP_FILE
	mv -f $TMP_FILE $CONFIG_DIR/$CONFIG_FILE
fi

grep -v "added by APM driver" $USER_BOOT_SCRIPT > $TMP_FILE
mv -f $TMP_FILE $USER_BOOT_SCRIPT

alert --info "APM Driver has been uninstalled and APM has been disabled."

rm -f $PREFIX*
exit 0;
fi
