#!/bin/sh
copyattr -d mobility.driver /boot/home/config/add-ons/kernel/drivers/bin
ln -s /boot/home/config/add-ons/kernel/drivers/bin/mobility.driver /boot/home/config/add-ons/kernel/drivers/dev/graphics/mobility.driver
copyattr -d mobility.accelerant /boot/home/config/add-ons/accelerants
echo Mobility driver installed. Reboot system.
