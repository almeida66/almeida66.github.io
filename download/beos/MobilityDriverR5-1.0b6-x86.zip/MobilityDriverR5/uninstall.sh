#!/bin/sh
rm -f /boot/home/config/add-ons/kernel/drivers/bin/mobility.driver /boot/home/config/add-ons/kernel/drivers/dev/graphics/mobility.driver
rm -f /boot/home/config/add-ons/accelerants/mobility.accelerant
echo Mobility driver uninstalled. Reboot system.
